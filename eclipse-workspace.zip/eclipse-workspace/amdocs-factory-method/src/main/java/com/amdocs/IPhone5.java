package com.amdocs;

public class IPhone5 implements Imobile {

	public void call() {
		// TODO Auto-generated method stub
		System.out.println("calling from Iphone5...");
	}

}
