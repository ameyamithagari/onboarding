package com.amdocs;

public class IPhone4 implements Imobile {

	public void call() {
		// TODO Auto-generated method stub
		System.out.println("calling from Iphone4...");
	}

}
