package com.amdocs;

public class OnePlus5 implements Imobile {

	public void call() {
		// TODO Auto-generated method stub
		System.out.println("calling from oneplus5...");
	}

}
