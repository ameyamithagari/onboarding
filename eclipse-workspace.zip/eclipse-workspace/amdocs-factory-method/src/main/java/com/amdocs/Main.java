package com.amdocs;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Imobile mobile= MobileFactory.getMobile("OnePlus7");
		mobile.call();

	}

}
