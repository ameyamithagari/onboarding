package com.amdocs;

public class NullMobile implements Imobile {

	public void call() {
		// TODO Auto-generated method stub
		System.out.println("invalid nmobie object");
		System.out.println("perform error log and error handling here");
	}

}
