/**
 * 
 */
package com.amdocs;

/**
 * @author train
 *
 */
public interface Imobile {
	public void call();
}
