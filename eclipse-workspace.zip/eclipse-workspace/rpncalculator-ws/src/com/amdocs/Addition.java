package com.amdocs;

public class Addition implements IMathOperation {

	public double evaluate(double firstNumber, double secondNumber) {
		// TODO Auto-generated method stub
		
		return firstNumber+ secondNumber;
	}

}
