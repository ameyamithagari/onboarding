package com.amdocs;

public class Subtraction implements IMathOperation {

	public double evaluate(double firstNumber, double secondNumber) {
		// TODO Auto-generated method stub
		return firstNumber - secondNumber;
	}

}
