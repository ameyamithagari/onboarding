package com.amdocs;

public class Division implements IMathOperation {

	public double evaluate(double firstNumber, double secondNumber) {
		// TODO Auto-generated method stub
		return firstNumber / secondNumber;
	}

}
