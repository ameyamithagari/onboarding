package com.amdocs;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class Hello {
	@WebMethod
	public String sayHello() {
		return "hello SOAP API!";
	}

}
