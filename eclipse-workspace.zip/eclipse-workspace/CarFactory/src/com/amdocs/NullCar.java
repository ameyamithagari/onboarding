package com.amdocs;

public class NullCar {
	public void drive () {
		System.out.println("no car found");
		}
}
