package com.amdocs;

public class AudiQ7 {
	public void drive () {
	System.out.println("this is audi Q7");
	}
}
