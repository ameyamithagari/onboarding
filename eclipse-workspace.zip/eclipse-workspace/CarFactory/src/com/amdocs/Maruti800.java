package com.amdocs;

public class Maruti800 {
	
	Icar= new Maruti800();
	return Icar;
	//public void drive () {
	//System.out.println("this is maruti 800");
}

