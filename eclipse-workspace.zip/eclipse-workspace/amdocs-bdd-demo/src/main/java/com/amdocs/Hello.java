package com.amdocs;

public class Hello {

	public String sayHello() {
		// TODO Auto-generated method stub
		//System.out.println("Hello BDD!");
		return "Hello BDD!";
	}

}
