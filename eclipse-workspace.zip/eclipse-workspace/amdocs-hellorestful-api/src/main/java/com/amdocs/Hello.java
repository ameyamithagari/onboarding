package com.amdocs;

import org.springframework.stereotype.Service;

@Service
public class Hello {

	public String sayHello() {
		// TODO Auto-generated method stub
		return "Hello REST API!";
	}

}
