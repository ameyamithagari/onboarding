package com.amdocs;

public class Hello {
	public String sayhello() {
		return "Hello Maven!" ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hello hello= new Hello();
		System.out.println(hello.sayhello());
	}

}
