package com.amdocs;

public class InsufficientBalanceException extends Exception {

}
