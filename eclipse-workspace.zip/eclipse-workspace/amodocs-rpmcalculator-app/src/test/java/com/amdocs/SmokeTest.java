package com.amdocs;

public interface SmokeTest {

}
