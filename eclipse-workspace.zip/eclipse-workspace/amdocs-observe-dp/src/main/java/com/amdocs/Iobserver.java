package com.amdocs;

public interface Iobserver {
	public void update(String message);
}
