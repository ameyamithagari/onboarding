package com.amdocs;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PaperWala paperWala = new PaperWala("pune paperwala private ltd");
		paperWala.addSubsriber(new subscriber("ramesh"));
	}

}
