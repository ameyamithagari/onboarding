package com.amdocs;

public class Subscriber implements Iobserver {

	public void update(String message) {
		// TODO Auto-generated method stub
			System.out.println(message);
	}

}
