@javax.xml.bind.annotation.XmlSchema(namespace = "http://amdocs.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.amdocs;
