package com.amdocs;

public class Camera {

	public boolean on() {
		// TODO Auto-generated method stub
		System.out.println("camera on method");
		System.out.println("assume camera hardware interaction happens here");
		
		return true;
	}

}
