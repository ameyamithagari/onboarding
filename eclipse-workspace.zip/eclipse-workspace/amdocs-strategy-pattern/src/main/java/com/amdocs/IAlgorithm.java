package com.amdocs;

public interface IAlgorithm {
	public void sort();

}
