package com.amdocs;

public class InsertionSort implements IAlgorithm {

	public void sort() {
		// TODO Auto-generated method stub
		System.out.println("Insertion Sort Algorithm invoked");

	}

}
