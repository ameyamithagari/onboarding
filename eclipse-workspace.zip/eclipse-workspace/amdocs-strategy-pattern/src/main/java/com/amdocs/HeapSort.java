package com.amdocs;

public class HeapSort implements IAlgorithm {

	public void sort() {
		// TODO Auto-generated method stub
		System.out.println("Heap Sort Algorithm invoked");

	}

}
