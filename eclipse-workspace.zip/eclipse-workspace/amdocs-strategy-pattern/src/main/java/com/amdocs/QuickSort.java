package com.amdocs;

public class QuickSort implements IAlgorithm {

	public void sort() {
		// TODO Auto-generated method stub
		System.out.println("Quick Sort Algorithm invoked");

	}

}
