package com.amdocs;

public class NullAlgorithm implements IAlgorithm {

	public void sort() {

		System.out.println("invalid nmobie object");
		System.out.println("perform error log and error handling here");
	}
}

