package com.amdocs;

public class Hello {
	//main ctrl+space
	public static void main(String[] args) {
		//syso ctrl+space
		System.out.println("hello java!");
		
	}

}
