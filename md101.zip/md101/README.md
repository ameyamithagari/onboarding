# MD101 - Step 7: Deleting Users

The basic functionality for your **user-service** application is almost complete. Consumers can now create users (with POST), retrieve them (with GET), and update them (with PUT). All that's left is allowing consumers to remove a user that's no longer needed.

For the final step in this chapter, you will implement a RESTful way to delete a user from your service. To do this, you will use the HTTP verb DELETE.

_**Need to go back to the previous step?** In the Terminal, enter `git checkout step_6` and then refresh your browser._

---

## Removing Resources with DELETE

The DELETE method does exactly what it sounds like. It deletes resources--typically resources identified by the request URI. In general, a DELETE request should return a 200 (OK), 202 (Accepted), or 204 (No Content) response, depending on how the request/response is handled.

DELETE is considered idempotent. However, trying to delete a resource that no longer exists should produce a 404 (Not Found) response.

The flow for DELETE requests is similar to other requests, as shown below.

![Rest Diagram](images/deleteHandler.png "HTTP REST Request")

### How Does DELETE Fit Into user-service?

In this step, you will create a REST endpoint that uses the DELETE verb to remove an existing user from your application. The specification below describes how your endpoint should work.

Notice that, in this case, there is no request or response body. The request URI, HTTP verb, and response code should tell you all you need to know about this request and response.

```
Request:
HTTP DELETE /users/1

Response:
204 NO CONTENT

...and then a follow up request...

Request:
HTTP DELETE /users/1

Response:
404 NOT FOUND
```

### Choosing HTTP Response Codes

Throughout this chapter, you've used a variety of HTTP response codes: 404, 500, 200, 204, and 201. A response code can convey a lot of information about a REST service. So think carefully about which to use. If needed, refer to the RFC 7231 specification to make sure you're using a response code correctly. Finally, be wary of any service that always returns a 200 (OK), even for error cases.

---

## Implementing DELETE Into user-service

Now that you have a general idea of what you need to make, you can begin implementing it. As in previous steps, this is a good time to start writing your tests. If you need help, see the test examples at the end of this README, as well as in the **end** project in STS.

### Modify UserService to Delete Users

First, you need to add a service method to delete users from the list of existing users.

The code block below shows how the new `deleteUser` method should look in `UserService` (See the **end** project in STS for the complete service code.)

```java
	public void deleteUser(final String userId) {
		users.removeIf(u -> u.getId().equalsIgnoreCase(userId));
	}
```

#### What Just Happened?

There's not a lot going on here--you're just removing an element from the list of users if the ID passed to the method matches an item in the list.

### Modify UserController to Handle Deleting Users

Now that you have your business logic in your service, you need to update the handler in your controller. According to the specification above, you need to do the following:

1. Create a method that maps an HTTP DELETE request to `/users/${id}` to the `deleteUser` method.
2. Check to see if this user exists. If not, return a 404.
3. If the user does exist, delete it and return a 204.

The code block below shows how the new `deleteUser` method should look in `UserController`. (Again, see the **end** project in STS for the complete controller code.)

```java
	@RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity deleteUser(@PathVariable final String id) {

		final Optional<User> user = this.userService.getUserById(id);
		if (!user.isPresent()) {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		} else {
			this.userService.deleteUser(user.get().getId());
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
```

#### What Just Happened?

This should look pretty familiar to you by now. Once again, `UserController` will take the request and map it to the correct method based on the type of request (a DELETE, in this case). This time you don't need to use the `@Valid` annotation--no data is being passed with the request, so there's nothing to validate.

---

## Building and Running

Now for the fun part--trying out your new functionality. Build and run your application as usual using `mvn clean verify` and `java -jar target/*.jar`. (Remember, you need to run these commands in Terminal in the **md101/sandbox/user-service** directory.)

After your application is running, try out the curl commands below in a new Terminal window.

### Get an Existing User

Run the following command to get the existing user with the ID of `1`.

````
curl -v "http://localhost:8080/users/1"
````

Details for the user are returned as JSON.

```
curl -v "http://localhost:8080/users/1"
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 8080 (#0)
> GET /users/1 HTTP/1.1
> Host: localhost:8080
> User-Agent: curl/7.54.0
> Accept: */*
> 
< HTTP/1.1 200 
< Content-Type: application/json;charset=UTF-8
< Transfer-Encoding: chunked
< Date: Fri, 06 Jul 2018 19:00:56 GMT
< 
* Connection #0 to host localhost left intact
{"firstName":"Green","lastName":"Anne","middleInitial":"A","userType":"VENUE_OWNER","dateOfBirth":"1983-02-09","id":"1"
```

### Delete an Existing User

Now run the following command to delete the user with the ID of `1`.

```
curl -v -X DELETE "http://localhost:8080/users/1"
```

The user is deleted, and a 204 (No Content) response is returned.

```
curl -v -X DELETE "http://localhost:8080/users/1"
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 8080 (#0)
> DELETE /users/1 HTTP/1.1
> Host: localhost:8080
> User-Agent: curl/7.54.0
> Accept: */*
> 
< HTTP/1.1 204 
< Date: Fri, 06 Jul 2018 19:01:28 GMT
< 
* Connection #0 to host localhost left intact
```

### Verify the User Was Deleted

Finally, run the following command to verify that the user with the ID of `1` no longer exists.

```
curl -v "http://localhost:8080/users/1"
```

A 404 (Not Found) status is returned, indicating the system cannot find a user with the ID of `1`. The deletion worked!

Don't forget to shut down your application with **CTRL+C** when you're done testing.

```
curl -v "http://localhost:8080/users/1"
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 8080 (#0)
> GET /users/1 HTTP/1.1
> Host: localhost:8080
> User-Agent: curl/7.54.0
> Accept: */*
> 
< HTTP/1.1 404 
< Content-Length: 0
< Date: Fri, 06 Jul 2018 19:04:13 GMT
< 
* Connection #0 to host localhost left intact
```

---

## Writing DELETE Action Tests

If you haven't already done so, don't forget to write unit and integration tests for your new DELETE action. You will want to have tests that can verify:

1. A delete request to your controller can return a 404 or 204.
2. A delete request to your service will delete an element from the list of users.
3. An HTTP DELETE request to your application server will successfully delete a user.

The code examples below show how you might implement your tests.

### UserServiceTest

```java
	@Test
	public void deleteUser() {
		userService.deleteUser("0");
		final Optional<User> retrievedUser = userService.getUserById("0");
		Assert.assertFalse(retrievedUser.isPresent());
	}
```

### UserControllerTest

```java
	@Test
	public void deleteUser() {

		final User user = new User("1", "test", "test", "t", UserType.PATRON, LocalDate.now());

		Mockito.when(userService.getUserById(Mockito.anyString())).thenReturn(Optional.of(user));

		final ResponseEntity responseEntity = this.controller.deleteUser("1");
		Assert.assertEquals(204, responseEntity.getStatusCodeValue());
		Assert.assertNull(responseEntity.getBody());
	}
```

### UserIntegrationTest

```java
	@Test
	public void deleteUser() throws Exception {
		this.restTemplate.delete("http://localhost:" + port + "/users/0");
		final ResponseEntity<User> responseEntity = this.restTemplate
				.getForEntity("http://localhost:" + port + "/users/0", User.class);
		Assert.assertEquals(404, responseEntity.getStatusCodeValue());
		Assert.assertNull(responseEntity.getBody());

	}
```

---

## Summary

In this step, you added the ability to delete a user by implementing a REST endpoint to handle HTTP DELETE requests. You then verified the new functionality using cURL commands

Congratulations--you have now finished building a simple REST microservice in Spring! In the next chapter, you will enable monitoring and managing for your service with Spring Boot Actuator.

_**Want to learn more?** See the "Dive Deeper" section in the chapter introduction (Jam page) for links to articles and videos about the topics in this chapter._
