package org.amdocs.elearning.user.service.user;

public enum UserType {
	PATRON, VENUE_OWNER
}
